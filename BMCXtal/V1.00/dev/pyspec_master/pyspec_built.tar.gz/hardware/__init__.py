#
#  @(#)__init__.py	6.1  05/11/20 CSS
#  "pyspec" Release 6
#

import sys
import os
sys.path.append(os.path.dirname(os.path.realpath(__file__)))
